public interface H {

    Object pp();

    int af();
}
