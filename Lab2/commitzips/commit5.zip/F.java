public class F extends B {

    private long c = 1234;

    private String f = "init";

    public double ee() {
        return 500.100;
    }

    public long dd() {
        return 33;
    }

    public void aa() {
        System.out.println("void aa");
    }

    public long ac() {
        return 222;
    }
}
