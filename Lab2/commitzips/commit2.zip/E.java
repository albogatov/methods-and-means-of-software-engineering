public interface E {

    String kk();

    java.lang.Class qq();
}
