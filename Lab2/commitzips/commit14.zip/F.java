public class F extends B {

    private long c = 1234;

    private String f = "init";

    public double ee() {
        return 500.100;
    }

    public long dd() {
        return 33;
    }

    public void aa() {
        System.out.println("Hello world!");
    }

    public String nn() {
        return "++++++++++[>+++++++>++++++++++>+++>+<<<<-]>++";
    }

    public long ac() {
        return 222;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public float ff() {
        return 3.14;
    }

    public double ad() {
        return java.lang.Math.sqrt(13);
    }

    public int hh() {
        return new java.util.Random(10).nextInt(10);
    }

    public java.util.Set<Integer> ll() {
        return new java.util.HashSet<Integer>;
    }
}
