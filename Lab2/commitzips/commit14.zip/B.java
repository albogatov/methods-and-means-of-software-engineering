public class B extends null implements E, H {

    private String i = "init";

    private String c = "init";

    public int cc() {
        return 13;
    }

    public Object rr() {
        return null;
    }

    public String kk() {
        return "Yes";
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public Object pp() {
        return this;
    }

    public int af() {
        return -1;
    }

    public java.util.List<String> jj() {
        return new java.util.ArrayList<String>();
    }

    public double ad() {
        return 11;
    }

    public double ee() {
        return 500.100;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public long dd() {
        return 33;
    }

    public void ab() {
        return;
    }

    public int ae() {
        return java.lang.Math.abs(-7);
    }

    public byte oo() {
        return 3;
    }
}
