public class H extends null {

    Object pp();

    int af();
}
