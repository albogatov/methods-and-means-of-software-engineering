public class B implements E, H {

    private String i = "init";

    private String c = "init";

    public int cc() {
        return 13;
    }

    public Object rr() {
        return null;
    }

    public String kk() {
        return "Yes";
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public Object pp() {
        return this;
    }

    public int af() {
        return -1;
    }

    public double ad() {
        return 11;
    }
}
