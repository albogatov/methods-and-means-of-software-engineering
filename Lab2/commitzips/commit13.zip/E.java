public class E extends null {

    String kk();

    java.lang.Class qq();
}
