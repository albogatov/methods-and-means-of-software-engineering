public class F extends B {

    private long c = 1234;

    private String f = "init";

    public double ee() {
        return 500.100;
    }

    public long dd() {
        return 33;
    }

    public void aa() {
        System.out.println("void aa");
    }

    public long ac() {
        return 222;
    }

    public Object gg() {
        return return getClass().getClassLoader();
    }

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }
}
